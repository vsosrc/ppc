
# The file containing the running pid
PID_FILE=/var/run/webhcat/webhcat.pid

TEMPLETON_LOG_DIR=/var/log/webhcat/


WEBHCAT_LOG_DIR=/var/log/webhcat/

# The console error log
ERROR_LOG=/var/log/webhcat/webhcat-console-error.log

# The console log
CONSOLE_LOG=/var/log/webhcat/webhcat-console.log

#TEMPLETON_JAR=templeton_jar_name

#HADOOP_PREFIX=hadoop_prefix

#HCAT_PREFIX=hive_prefix

# Set HADOOP_HOME to point to a specific hadoop install directory
export HADOOP_HOME=/opt/vse/hadoop
