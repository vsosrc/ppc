var searchData=
[
  ['type',['Type',['../classAvro_1_1Schema.html#a8ed00d717151392cd91465cd1a562354',1,'Avro::Schema']]]
];
