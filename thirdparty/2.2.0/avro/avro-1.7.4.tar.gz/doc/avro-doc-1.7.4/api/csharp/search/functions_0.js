var searchData=
[
  ['add',['Add',['../classAvro_1_1SchemaNames.html#aeafe6e15130520c784220e036b53fed2',1,'Avro.SchemaNames.Add(SchemaName name, NamedSchema schema)'],['../classAvro_1_1SchemaNames.html#a48054e67c2145be090021805424a23af',1,'Avro.SchemaNames.Add(NamedSchema schema)']]],
  ['addfield',['AddField',['../classAvro_1_1Generic_1_1DefaultReader.html#a52aa5bef7aa911918323c51c93fc874f',1,'Avro::Generic::DefaultReader']]],
  ['addmapentry',['AddMapEntry',['../classAvro_1_1Generic_1_1DefaultReader.html#a0adcc527a4d5fbca5c3a7293beb4a410',1,'Avro::Generic::DefaultReader']]],
  ['addname',['addName',['../classAvro_1_1CodeGen.html#a0713934c0acf842587e7ddd929487a37',1,'Avro::CodeGen']]],
  ['addnamespace',['addNamespace',['../classAvro_1_1CodeGen.html#a80bc14c85e4f67cc7fce036725f9f616',1,'Avro::CodeGen']]],
  ['addprotocol',['AddProtocol',['../classAvro_1_1CodeGen.html#a68219f5b1e750d54895bd153dac444e9',1,'Avro::CodeGen']]],
  ['addschema',['AddSchema',['../classAvro_1_1CodeGen.html#ad4bef6a5c3f0e347d4f4314c4c42c437',1,'Avro::CodeGen']]],
  ['areequal',['areEqual',['../classAvro_1_1Message.html#a476a53e85f51a1153427550096e269ad',1,'Avro.Message.areEqual()'],['../classAvro_1_1Schema.html#a56fa19802b021515e03ae64f1ca899c2',1,'Avro.Schema.areEqual()']]]
];
