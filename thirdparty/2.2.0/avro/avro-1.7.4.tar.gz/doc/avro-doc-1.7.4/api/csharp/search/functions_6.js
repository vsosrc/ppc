var searchData=
[
  ['namedschema',['NamedSchema',['../classAvro_1_1NamedSchema.html#afe64baafbcbad0b9462c0afe8523fe34',1,'Avro::NamedSchema']]],
  ['new',['New',['../classAvro_1_1Specific_1_1ObjectCreator.html#a594c036b3c822b3499f1060215b5710f',1,'Avro::Specific::ObjectCreator']]],
  ['newinstance',['NewInstance',['../classAvro_1_1PrimitiveSchema.html#ab555f27bf6b0b7a3c8b532854263110c',1,'Avro::PrimitiveSchema']]]
];
