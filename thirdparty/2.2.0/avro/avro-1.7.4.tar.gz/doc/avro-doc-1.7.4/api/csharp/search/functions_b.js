var searchData=
[
  ['tostring',['ToString',['../classAvro_1_1Protocol.html#a3983bef6161d1d6d3f6c36d5d1bc1b77',1,'Avro.Protocol.ToString()'],['../classAvro_1_1Schema.html#a53b49fa96b56eb63d9919c64cb936f2f',1,'Avro.Schema.ToString()'],['../classAvro_1_1SchemaName.html#a29efc075a70595dd1a38a0bc32ca9f16',1,'Avro.SchemaName.ToString()']]],
  ['trygetfield',['TryGetField',['../classAvro_1_1Generic_1_1DefaultReader.html#a2c088ce2baaf7b9eb339a3153622e03a',1,'Avro::Generic::DefaultReader']]],
  ['trygetvalue',['TryGetValue',['../classAvro_1_1SchemaNames.html#ae01f5d07aef76e03852b4ff752b41d7b',1,'Avro::SchemaNames']]]
];
