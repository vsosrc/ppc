var searchData=
[
  ['itemschema',['ItemSchema',['../classAvro_1_1ArraySchema.html#a733281cea9ed15e74b31f6da48269f21',1,'Avro::ArraySchema']]]
];
