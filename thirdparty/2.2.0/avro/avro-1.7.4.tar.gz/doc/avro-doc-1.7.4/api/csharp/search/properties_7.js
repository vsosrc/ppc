var searchData=
[
  ['oneway',['Oneway',['../classAvro_1_1Message.html#acd3cb031d3fbd974b233cebf6b65ccfb',1,'Avro::Message']]],
  ['ordering',['Ordering',['../classAvro_1_1Field.html#a93d852d70cd612ea6a7963f1cc1e7360',1,'Avro::Field']]]
];
