var searchData=
[
  ['schema',['Schema',['../classAvro_1_1Field.html#a78b5f90134c2b9adf3454086c4df1ae3',1,'Avro::Field']]],
  ['schemaname',['SchemaName',['../classAvro_1_1NamedSchema.html#ae82253395dec36e22de833b78d1d6d73',1,'Avro::NamedSchema']]],
  ['schemas',['Schemas',['../classAvro_1_1CodeGen.html#a1ab50fbfca1db89d1c9f1eed777b788d',1,'Avro.CodeGen.Schemas()'],['../classAvro_1_1UnionSchema.html#aeb232612208f1ec6fe1f282d1d5a20f9',1,'Avro.UnionSchema.Schemas()']]],
  ['size',['Size',['../classAvro_1_1FixedSchema.html#af55b0a007aea1d359a599252b65fda82',1,'Avro::FixedSchema']]],
  ['space',['Space',['../classAvro_1_1SchemaName.html#a5f4f4d30c6c3daabf27fe3c84149a063',1,'Avro::SchemaName']]],
  ['symbols',['Symbols',['../classAvro_1_1EnumSchema.html#a331aacb3cfb36813f3990e471c594c33',1,'Avro::EnumSchema']]]
];
