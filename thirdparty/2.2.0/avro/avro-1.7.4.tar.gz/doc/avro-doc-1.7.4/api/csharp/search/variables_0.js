var searchData=
[
  ['aliases',['aliases',['../classAvro_1_1Field.html#a66b8325b9068d05d429efd6c813f72a7',1,'Avro::Field']]]
];
