var searchData=
[
  ['unionschema',['UnionSchema',['../classAvro_1_1UnionSchema.html',1,'Avro']]],
  ['unmangle',['UnMangle',['../classAvro_1_1CodeGenUtil.html#ae730ab755f50c5ac6f7388323718c991',1,'Avro::CodeGenUtil']]],
  ['unnamedschema',['UnnamedSchema',['../classAvro_1_1UnnamedSchema.html',1,'Avro']]]
];
