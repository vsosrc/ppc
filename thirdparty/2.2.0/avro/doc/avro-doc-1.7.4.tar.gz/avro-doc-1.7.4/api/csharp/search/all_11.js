var searchData=
[
  ['valueschema',['ValueSchema',['../classAvro_1_1MapSchema.html#aab9e951199ff26809a27c3d6fc6343ca',1,'Avro::MapSchema']]]
];
