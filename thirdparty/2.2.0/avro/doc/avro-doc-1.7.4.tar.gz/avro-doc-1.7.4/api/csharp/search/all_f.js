var searchData=
[
  ['tag',['Tag',['../classAvro_1_1Schema.html#a5aeb2ac19804aaf235a68b3df3a16bd2',1,'Avro::Schema']]],
  ['this_5bint_20index_5d',['this[int index]',['../classAvro_1_1EnumSchema.html#a198a24e78c67207cc6bfcf3666a76b9f',1,'Avro.EnumSchema.this[int index]()'],['../classAvro_1_1UnionSchema.html#a5f972c4ebd5af926ce1531cb7461004d',1,'Avro.UnionSchema.this[int index]()']]],
  ['this_5bstring_20name_5d',['this[string name]',['../classAvro_1_1RecordSchema.html#ad135dca9accbe9bf1a4e9cd820130a5a',1,'Avro::RecordSchema']]],
  ['tostring',['ToString',['../classAvro_1_1Protocol.html#a3983bef6161d1d6d3f6c36d5d1bc1b77',1,'Avro.Protocol.ToString()'],['../classAvro_1_1Schema.html#a53b49fa96b56eb63d9919c64cb936f2f',1,'Avro.Schema.ToString()'],['../classAvro_1_1SchemaName.html#a29efc075a70595dd1a38a0bc32ca9f16',1,'Avro.SchemaName.ToString()']]],
  ['trygetfield',['TryGetField',['../classAvro_1_1Generic_1_1DefaultReader.html#a2c088ce2baaf7b9eb339a3153622e03a',1,'Avro::Generic::DefaultReader']]],
  ['trygetvalue',['TryGetValue',['../classAvro_1_1SchemaNames.html#ae01f5d07aef76e03852b4ff752b41d7b',1,'Avro::SchemaNames']]],
  ['type',['Type',['../classAvro_1_1Schema.html#a8ed00d717151392cd91465cd1a562354',1,'Avro::Schema']]],
  ['types',['Types',['../classAvro_1_1Protocol.html#a4db643761d1f913174fec78e03a72740',1,'Avro::Protocol']]]
];
