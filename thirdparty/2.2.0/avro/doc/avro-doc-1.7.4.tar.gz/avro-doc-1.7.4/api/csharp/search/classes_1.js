var searchData=
[
  ['binarydecoder',['BinaryDecoder',['../classAvro_1_1IO_1_1BinaryDecoder.html',1,'Avro::IO']]],
  ['binaryencoder',['BinaryEncoder',['../classAvro_1_1IO_1_1BinaryEncoder.html',1,'Avro::IO']]]
];
