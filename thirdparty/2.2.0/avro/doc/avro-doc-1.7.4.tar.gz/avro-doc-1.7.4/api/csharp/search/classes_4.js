var searchData=
[
  ['encoder',['Encoder',['../interfaceAvro_1_1IO_1_1Encoder.html',1,'Avro::IO']]],
  ['enumschema',['EnumSchema',['../classAvro_1_1EnumSchema.html',1,'Avro']]]
];
