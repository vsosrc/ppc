var searchData=
[
  ['mapschema',['MapSchema',['../classAvro_1_1MapSchema.html',1,'Avro']]],
  ['message',['Message',['../classAvro_1_1Message.html',1,'Avro']]]
];
