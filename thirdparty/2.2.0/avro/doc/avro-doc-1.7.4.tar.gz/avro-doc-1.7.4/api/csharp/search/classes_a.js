var searchData=
[
  ['namectorkey',['NameCtorKey',['../structAvro_1_1Specific_1_1ObjectCreator_1_1NameCtorKey.html',1,'Avro::Specific::ObjectCreator']]],
  ['namedschema',['NamedSchema',['../classAvro_1_1NamedSchema.html',1,'Avro']]]
];
