var searchData=
[
  ['recordschema',['RecordSchema',['../classAvro_1_1RecordSchema.html',1,'Avro']]]
];
