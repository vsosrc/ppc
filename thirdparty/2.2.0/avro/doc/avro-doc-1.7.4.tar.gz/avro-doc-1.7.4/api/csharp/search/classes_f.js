var searchData=
[
  ['unionschema',['UnionSchema',['../classAvro_1_1UnionSchema.html',1,'Avro']]],
  ['unnamedschema',['UnnamedSchema',['../classAvro_1_1UnnamedSchema.html',1,'Avro']]]
];
