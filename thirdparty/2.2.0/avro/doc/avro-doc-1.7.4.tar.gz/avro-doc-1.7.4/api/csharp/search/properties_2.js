var searchData=
[
  ['encspace',['EncSpace',['../classAvro_1_1SchemaName.html#a325a61a810cd640a82e015ae96abbe6d',1,'Avro::SchemaName']]],
  ['error',['Error',['../classAvro_1_1Message.html#a05172c652d33288568dce415dc77543f',1,'Avro::Message']]]
];
