var searchData=
[
  ['fields',['Fields',['../classAvro_1_1RecordSchema.html#a131abee86b769b819506974140d11ad3',1,'Avro::RecordSchema']]],
  ['fullname',['Fullname',['../classAvro_1_1NamedSchema.html#a100cdeb64045214ab55c947f127e7a24',1,'Avro.NamedSchema.Fullname()'],['../classAvro_1_1SchemaName.html#a6f20459b3693e17ef8d34eda84082bf4',1,'Avro.SchemaName.Fullname()']]]
];
