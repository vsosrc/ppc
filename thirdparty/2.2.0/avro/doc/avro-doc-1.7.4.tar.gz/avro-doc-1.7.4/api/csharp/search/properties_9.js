var searchData=
[
  ['readerschema',['ReaderSchema',['../classAvro_1_1Specific_1_1SpecificReader_3_01T_01_4.html#a042a244eca8615c528e0c72e7957193a',1,'Avro::Specific::SpecificReader&lt; T &gt;']]],
  ['request',['Request',['../classAvro_1_1Message.html#a7cd3b95edcc91e22fc59f22f884f4a65',1,'Avro::Message']]],
  ['response',['Response',['../classAvro_1_1Message.html#ab232ba665cdcb1de72b2bbf4976447ed',1,'Avro::Message']]]
];
