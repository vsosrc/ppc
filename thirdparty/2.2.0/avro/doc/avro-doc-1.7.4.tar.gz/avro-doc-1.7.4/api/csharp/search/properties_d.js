var searchData=
[
  ['writerschema',['WriterSchema',['../classAvro_1_1Specific_1_1SpecificReader_3_01T_01_4.html#a5028515976f1498436b3591860e346fa',1,'Avro::Specific::SpecificReader&lt; T &gt;']]]
];
