#!/bin/bash

#  HBASE integration tests 

# ************ run hbase shell with commands in file hbase-test.txt

/opt/vse/hbase/bin/hbase shell hbase-com.txt

