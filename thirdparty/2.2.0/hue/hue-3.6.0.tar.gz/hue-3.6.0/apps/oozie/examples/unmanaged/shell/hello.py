#!/usr/bin/env python

import sys

print 'Hello ' + ', '.join(sys.argv[1:])

