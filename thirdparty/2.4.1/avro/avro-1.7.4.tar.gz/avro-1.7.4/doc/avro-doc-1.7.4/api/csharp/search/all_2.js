var searchData=
[
  ['canread',['CanRead',['../classAvro_1_1ArraySchema.html#a17def6e1d896af6f762f61c53db0eadd',1,'Avro.ArraySchema.CanRead()'],['../classAvro_1_1EnumSchema.html#a74a9eceeaa26dc2ff5d0b0f41937118b',1,'Avro.EnumSchema.CanRead()'],['../classAvro_1_1FixedSchema.html#a651a9e8b2e042a6306fc95dbeb86293f',1,'Avro.FixedSchema.CanRead()'],['../classAvro_1_1MapSchema.html#a91a53bc339bb727f8e85ec60c3ceeb26',1,'Avro.MapSchema.CanRead()'],['../classAvro_1_1PrimitiveSchema.html#a0d7d37ad364a40a29625cf5ffc6afa45',1,'Avro.PrimitiveSchema.CanRead()'],['../classAvro_1_1RecordSchema.html#a06f9434cd52400a75968ffd89528d95e',1,'Avro.RecordSchema.CanRead()'],['../classAvro_1_1Schema.html#a3857a4547a0d29f494b336b10b9b7576',1,'Avro.Schema.CanRead()'],['../classAvro_1_1UnionSchema.html#a392e203bc72d46a8a4ba8cd2f45c3e8f',1,'Avro.UnionSchema.CanRead()']]],
  ['codegen',['CodeGen',['../classAvro_1_1CodeGen.html',1,'Avro']]],
  ['codegen',['CodeGen',['../classAvro_1_1CodeGen.html#af249a4cfaa748b1260bdf943c7f0449f',1,'Avro::CodeGen']]],
  ['codegenexception',['CodeGenException',['../classAvro_1_1CodeGenException.html',1,'Avro']]],
  ['codegenutil',['CodeGenUtil',['../classAvro_1_1CodeGenUtil.html',1,'Avro']]],
  ['compileunit',['CompileUnit',['../classAvro_1_1CodeGen.html#a739972d3cc573ad8a7ed796b3237d458',1,'Avro::CodeGen']]],
  ['contains',['Contains',['../classAvro_1_1EnumSchema.html#a4792ec980f22f9e492ee2bdef0f0945a',1,'Avro.EnumSchema.Contains()'],['../classAvro_1_1RecordSchema.html#a6a6a0793adfdcd0e4222d48f2c8f8831',1,'Avro.RecordSchema.Contains()'],['../classAvro_1_1SchemaNames.html#ac2dcece88cc10d49206978ca14bb5c7a',1,'Avro.SchemaNames.Contains()']]],
  ['count',['Count',['../classAvro_1_1EnumSchema.html#a10bc82ec6b196dbb7bf17850ec2fea45',1,'Avro.EnumSchema.Count()'],['../classAvro_1_1RecordSchema.html#a5f5aaec9535da10b6a9a086ce388107a',1,'Avro.RecordSchema.Count()'],['../classAvro_1_1UnionSchema.html#a4b0f86b7f5c88915f262f24bcabd3cd5',1,'Avro.UnionSchema.Count()']]],
  ['createarray',['CreateArray',['../classAvro_1_1Generic_1_1DefaultReader.html#a1e701679f6698f28c66975ff87381161',1,'Avro::Generic::DefaultReader']]],
  ['createdoccomment',['createDocComment',['../classAvro_1_1CodeGen.html#af57b8a84d912187852e62755c542cc7b',1,'Avro::CodeGen']]],
  ['createenum',['CreateEnum',['../classAvro_1_1Generic_1_1DefaultReader.html#ac0bc5996b55a6b79bc6355e56fa3ffdc',1,'Avro::Generic::DefaultReader']]],
  ['createfixed',['CreateFixed',['../classAvro_1_1Generic_1_1DefaultReader.html#af1f1015b79f117924b66f348720eebe0',1,'Avro::Generic::DefaultReader']]],
  ['createmap',['CreateMap',['../classAvro_1_1Generic_1_1DefaultReader.html#aeef893f25d26d76263dd055ad725697d',1,'Avro::Generic::DefaultReader']]],
  ['createrecord',['CreateRecord',['../classAvro_1_1Generic_1_1DefaultReader.html#ad6e8a163f1fa5ca597fb1c3f977d24fd',1,'Avro::Generic::DefaultReader']]],
  ['createschemafield',['createSchemaField',['../classAvro_1_1CodeGen.html#a0512c256cd5cf8b95ba49824283d18dc',1,'Avro::CodeGen']]]
];
