var searchData=
[
  ['ispecificrecord',['ISpecificRecord',['../interfaceAvro_1_1Specific_1_1ISpecificRecord.html',1,'Avro::Specific']]]
];
