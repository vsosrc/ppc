var searchData=
[
  ['defaultreader',['DefaultReader',['../classAvro_1_1Generic_1_1DefaultReader.html#ab5a01ca3a4edc8867ee9b2d9c42d6238',1,'Avro::Generic::DefaultReader']]],
  ['defaultwriter',['DefaultWriter',['../classAvro_1_1Generic_1_1DefaultWriter.html#ac96c3ecdadda29bf66cfd576dd12b228',1,'Avro::Generic::DefaultWriter']]]
];
