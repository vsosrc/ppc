var searchData=
[
  ['mangle',['Mangle',['../classAvro_1_1CodeGenUtil.html#aa56c7bf6dbe808d332f7c88771f7ce2a',1,'Avro::CodeGenUtil']]],
  ['matchingbranch',['MatchingBranch',['../classAvro_1_1UnionSchema.html#a662af78cffb5fe5d5fdad41a8436e31e',1,'Avro::UnionSchema']]],
  ['message',['Message',['../classAvro_1_1Message.html#a79ca85d0e537073c6ecc0f8d41244d20',1,'Avro::Message']]]
];
