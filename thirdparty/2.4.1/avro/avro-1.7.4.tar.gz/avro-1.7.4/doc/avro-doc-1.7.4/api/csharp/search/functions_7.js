var searchData=
[
  ['ordinal',['Ordinal',['../classAvro_1_1EnumSchema.html#a01b7496c32463ef29125bfcfb0b2be3f',1,'Avro::EnumSchema']]]
];
