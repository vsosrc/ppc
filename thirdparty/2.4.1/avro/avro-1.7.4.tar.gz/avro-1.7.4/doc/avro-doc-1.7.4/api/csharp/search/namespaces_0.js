var searchData=
[
  ['avro',['Avro',['../namespaceAvro.html',1,'']]],
  ['generic',['Generic',['../namespaceAvro_1_1Generic.html',1,'Avro']]],
  ['io',['IO',['../namespaceAvro_1_1IO.html',1,'Avro']]],
  ['properties',['Properties',['../namespaceAvro_1_1Properties.html',1,'Avro']]],
  ['specific',['Specific',['../namespaceAvro_1_1Specific.html',1,'Avro']]]
];
