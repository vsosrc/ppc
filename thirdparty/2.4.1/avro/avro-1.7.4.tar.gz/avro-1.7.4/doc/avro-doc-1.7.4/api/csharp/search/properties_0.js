var searchData=
[
  ['compileunit',['CompileUnit',['../classAvro_1_1CodeGen.html#a739972d3cc573ad8a7ed796b3237d458',1,'Avro::CodeGen']]],
  ['count',['Count',['../classAvro_1_1EnumSchema.html#a10bc82ec6b196dbb7bf17850ec2fea45',1,'Avro.EnumSchema.Count()'],['../classAvro_1_1RecordSchema.html#a5f5aaec9535da10b6a9a086ce388107a',1,'Avro.RecordSchema.Count()'],['../classAvro_1_1UnionSchema.html#a4b0f86b7f5c88915f262f24bcabd3cd5',1,'Avro.UnionSchema.Count()']]]
];
