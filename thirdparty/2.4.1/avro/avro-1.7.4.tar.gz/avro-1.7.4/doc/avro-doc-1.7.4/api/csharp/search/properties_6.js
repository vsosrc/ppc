var searchData=
[
  ['name',['Name',['../classAvro_1_1Message.html#ae67595737ebef953f3998637ec6a7f75',1,'Avro.Message.Name()'],['../classAvro_1_1Protocol.html#ae55741e18ed015f4774338289f3b3a52',1,'Avro.Protocol.Name()'],['../classAvro_1_1NamedSchema.html#a081a65f8367496df2158d73b8fde954f',1,'Avro.NamedSchema.Name()'],['../classAvro_1_1Schema.html#a240a1466ad53c77899f72f48ab68b988',1,'Avro.Schema.Name()'],['../classAvro_1_1SchemaName.html#a09f73593b3cea0f7e54bf34eb01c15a2',1,'Avro.SchemaName.Name()']]],
  ['names',['Names',['../classAvro_1_1SchemaNames.html#ab2589a36ec213767b3609e67962834fb',1,'Avro::SchemaNames']]],
  ['namespace',['Namespace',['../classAvro_1_1Protocol.html#af8f6f5847e6cfb8601e70f8f97202086',1,'Avro.Protocol.Namespace()'],['../classAvro_1_1NamedSchema.html#a9a5e28a946f86ed364aad9744ddb3e0a',1,'Avro.NamedSchema.Namespace()'],['../classAvro_1_1SchemaName.html#a66788821ec1d52c365741a9d5caba660',1,'Avro.SchemaName.Namespace()']]]
];
