var searchData=
[
  ['pos',['Pos',['../classAvro_1_1Field.html#a617dcf15029e99c64d2af814cef9b68c',1,'Avro::Field']]],
  ['protocols',['Protocols',['../classAvro_1_1CodeGen.html#ae71b09f4a8df0951a3545991de53299a',1,'Avro::CodeGen']]]
];
