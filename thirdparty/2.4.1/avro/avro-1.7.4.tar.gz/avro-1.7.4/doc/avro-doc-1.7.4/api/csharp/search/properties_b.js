var searchData=
[
  ['tag',['Tag',['../classAvro_1_1Schema.html#a5aeb2ac19804aaf235a68b3df3a16bd2',1,'Avro::Schema']]],
  ['this_5bint_20index_5d',['this[int index]',['../classAvro_1_1EnumSchema.html#a198a24e78c67207cc6bfcf3666a76b9f',1,'Avro.EnumSchema.this[int index]()'],['../classAvro_1_1UnionSchema.html#a5f972c4ebd5af926ce1531cb7461004d',1,'Avro.UnionSchema.this[int index]()']]],
  ['this_5bstring_20name_5d',['this[string name]',['../classAvro_1_1RecordSchema.html#ad135dca9accbe9bf1a4e9cd820130a5a',1,'Avro::RecordSchema']]],
  ['types',['Types',['../classAvro_1_1Protocol.html#a4db643761d1f913174fec78e03a72740',1,'Avro::Protocol']]]
];
