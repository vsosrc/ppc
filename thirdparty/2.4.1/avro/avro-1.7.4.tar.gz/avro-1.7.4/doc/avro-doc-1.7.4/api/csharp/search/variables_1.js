var searchData=
[
  ['name',['Name',['../classAvro_1_1Field.html#a0e16e792054277f0533944502810359c',1,'Avro::Field']]],
  ['namespacelookup',['namespaceLookup',['../classAvro_1_1CodeGen.html#ae645f7090de6829128c32b426b6ee925',1,'Avro::CodeGen']]]
];
